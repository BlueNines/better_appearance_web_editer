# bajinengshiti 多轨道实体教程案例

这个包演示一个普通实体同时使用本体动作轨和多条附加模型轨道：

- `default` 轨使用 `controller.animation.entity_skill8.default`，播放 `skill1` 到 `skill8` 八套本体动作。
- `a-g` 轨使用 `controller.animation.entity_idle_skill1.a-g`，分别播放 `skill1A` 到 `skill1G`。
- `a-g` 模型使用 `controller.render.entity_default.a-g.third_person`，只在对应 `query.mod.entity_skill_x > 0` 时显示。

## 目录说明

- `组件/`：复制到 BetterAppearance 组件项目中的对应路径。
- `插件/src/main/resources/ActionEffect/GeoAction/LivingEntityAction/bajinengshiti.yml`：服务端套模型配置。
- `插件/examples/MythicMobs/Mobs/peba_bajinengshiti_action_test_mobs.yml`：MythicMobs 测试怪配置。

## 测试步骤

1. 把 `组件/` 下的文件复制到组件项目对应目录。
2. 把 `插件/src/main/resources/ActionEffect/GeoAction/LivingEntityAction/bajinengshiti.yml` 放到插件项目对应目录。
3. 把 `插件/examples/MythicMobs/Mobs/peba_bajinengshiti_action_test_mobs.yml` 复制到服务器 `MythicMobs/Mobs/`。
4. 重载插件和 MythicMobs。
5. 生成 `PEBA_Bajinengshiti_Action_Test` 测试怪。

## MM 播放方式

播放本体第 8 个技能：

```yaml
- peba_playAnimation{i=8;crs=2.10} @self
```

播放 A 轨附加模型动作：

```yaml
- peba_playAnimation{i=1;track=a;ds=0.5;crs=2.10} @self
```

注意：`ds` 是秒，`d` 是 tick。需要 0.5 秒延迟时写 `ds=0.5`，不要写 `d=0.5`。
