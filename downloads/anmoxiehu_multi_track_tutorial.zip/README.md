# 教程包说明

这个目录是“普通实体多模型多轨道播放教程”的教材示例包，示例实体是 `anmoxiehu`，中文名按素材命名为“暗魔邪虎”。

上级教程文档：

```text
../../普通实体多模型多轨道播放教程.md
```

## 目录说明

| 路径 | 说明 |
| --- | --- |
| `教程包.zip` | 本目录内容的压缩包，方便单独分发 |
| `导入到编辑器之前的模型/` | 融合前的本体模型、特效模型、动作和贴图 |
| `编辑器导出的内容/` | Web 编辑器导出的客户端资源和服务端配置快照 |
| `mm配置/暗魔邪虎.yml` | MythicMobs 测试怪示例 |
| `编辑器教程.rtf` | 原始编辑器操作说明 |

## 测试重点

这个示例用于验证：

- default 轨播放本体动作。
- A 轨播放特效动作。
- default 轨和 A 轨可以不同时间开始。
- default 轨和 A 轨可以不同时间归零。
- 不写 `track` 时仍然保持旧写法，只控制 default 轨。

## MM 最小示例

```yaml
测试怪:
  Type: HUSK
  Display: '§c测试怪'
  Health: 600
  Damage: 0
  Options:
    MovementSpeed: 0.01
    Silent: true
    NoAI: true
  Skills:
    - peba_injectionConfig{id=anmoxiehu;w=1.0;h=5;s=1;chc=1000;hbv=false;bbv=true} @self ~onSpawn
    - peba_playAnimation{i=2;crs=2.48} @self ~onTimer:180
    - peba_playAnimation{ds=0.5;i=2;track=a;crs=1.56} @self ~onTimer:180
```

`ds=0.5` 表示服务端延迟 0.5 秒发送 A 轨动作。不要写成 `d=0.5`，因为 `d` 是 tick 参数。

## 使用提醒

`编辑器导出的内容/` 是导出快照，适合做对照。当前项目最终落地配置已经整理到：

```text
src/main/resources/ActionEffect/GeoAction/LivingEntityAction/anmoxiehu.yml
```

正式测试时建议优先使用项目里的最终配置和：

```text
examples/MythicMobs/Mobs/peba_anmoxiehu_track_test_mobs.yml
```
