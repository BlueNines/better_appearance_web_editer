# test_mod:twoqiang 完整配置教程

本文以当前实际配置和组件资源为基准，说明 `test_mod:twoqiang` 从服务端识别物品，到客户端切换玩家模型、播放三段普攻、调整攻击速度、显示模型特效并执行服务端伤害指令的完整链路。

配套 ZIP 中保留了服务端当前原件，没有修改正在使用的 `C:\Users\28315\Desktop\fsdownload\BetterAppearance`。教程中会明确指出当前配置里需要技术人员确认的值，避免学习者误把测试参数当成推荐值。

- [HTTP 下载教程包.zip](https://bluenines.github.io/better_appearance_web_editer/downloads/test_mod_twoqiang_complete_tutorial.zip)

## 一、功能边界

当前服务端配置实际启用的是三段普通攻击：

```text
第 1 段：animation.test_mod_doublegun.attack_1
第 2 段：animation.test_mod_doublegun.attack_2
第 3 段：animation.test_mod_doublegun.attack_3
```

玩家等级通过 `%player_level%` 生成攻击速度倍率：

```text
S = min(1 + max(%player_level%, 0) * 0.02, 2)
```

对应结果：

| 等级 | 动作倍率 |
|---:|---:|
| 0 | 1.0 |
| 25 | 1.5 |
| 50 及以上 | 2.0 |

这套倍率当前同时控制：

- 玩家前三段攻击动画。
- 普攻模型特效前三段动画。
- `cdList` 的 `min`、`max`、`changeTime`。
- `specialEffectList` 的 `min`、`max`。
- `commandList` 的服务端指令 `delay`。

当前没有动态控制 `TrackingTimeConfig` 的刀光追踪时间。该配置仍使用静态秒数，后文会单独说明。

## 二、统一标识

整条链路最重要的是以下标识完全一致：

```text
test_mod:twoqiang
```

它同时出现在：

- 行为包物品的 `description.identifier`。
- 资源包附加物的 `description.identifier`。
- 服务端 `ActionEffect` 的配置节点和 `itemId`。
- 服务端 `WeaponAttackCDConfig` 的配置节点和 `itemId`。
- 服务端 `TrackingTimeConfig` 的配置节点和 `itemId`。
- 服务端 `WeaponAttackDamageConfig` 的配置节点和 `itemId`。
- 服务端物品系统写入主手物品的 `netease_identifier` NBT。

服务端物品必须至少带有：

```yaml
nbt:
  netease_identifier: "test_mod:twoqiang"
```

这里的 NBT 对服务端是物品识别值，对客户端则对应行为包和附加物的 identifier。

## 三、完整运行流程

```text
玩家主手切换到带 netease_identifier=test_mod:twoqiang 的物品
    ↓
服务端 PlayerAppearancePresetManager 读取真实主手标识
    ↓
没有单独 AppearancePreset 映射时，使用旧 itemId 配置生成兼容预设
    ↓
appearanceKey = test_mod:twoqiang
attackKey     = test_mod:twoqiang
    ↓
ActionEffect 配置负责模型、贴图、Render Controller、动作和动作控制器
WeaponAttackCDConfig 按玩家解析连击窗口、速度 Molang 和模型特效时间
WeaponAttackDamageConfig 按玩家解析服务端指令 delay
TrackingTimeConfig 下发静态刀光追踪时间
    ↓
服务端把客户端攻击快照和玩家外观预设发给客户端
服务端保留冷却校验窗口与伤害指令快照
    ↓
客户端第 N 段攻击先写入 query.mod.twoqiang_attack_speed
再写入 query.mod.attack=N，进入对应攻击动作
    ↓
specialEffectList 在指定时间把 query.mod.attack_special_effect 写为 1/2/3
附加物状态机播放对应的普攻模型特效动画
    ↓
服务端校验攻击段间隔，通过后按动态 delay 执行 apmm cast 指令
```

PlaceholderAPI 和数学表达式只在服务端刷新玩家快照时解析。每次攻击不会重新调用 PAPI，也不会为了攻击速度增加一次通信。

## 四、服务端配置

当前配置来自插件数据目录，不是插件 JAR 内置默认文件。配套包共保留九份双枪相关 YAML，其中四份属于 `test_mod:twoqiang` 普通攻击主链路，三份属于双枪技能链路，另两份属于旧标识 `test_mod:doublegun_normal`。

### 1. ActionEffect：模型和动作预设

文件：

```text
ActionEffect/GeoAction/NormalAttack/twoqiang.yml
```

职责：

- 把 `geometry.test_mod_doublegun` 注入玩家资源的 `weapon_ff` 槽位。
- 使用 `textures/entity/test_mod/twoqiang` 作为武器贴图。
- 添加双枪武器 Render Controller。
- 移除不需要的副手武器和部分原版动作。
- 把 `attack1/2/3` 映射到三段双枪攻击动作。
- 注入第三人称和第一人称动作控制器。

核心配置：

```yaml
"test_mod:twoqiang":
  itemId: "test_mod:twoqiang"

  geometry:
    - key: weapon_ff
      name: geometry.test_mod_doublegun
    - key: off_weapon
      isRemove: true

  texture:
    - key: weapon_ff
      name: textures/entity/test_mod/twoqiang

  render:
    - controller: controller.render.test_mod_weapon
      condition: ""
    - controller: controller.render.test_mod_off_weapon
      isRemove: true
    - controller: controller.render.test_mod_player.first_person_handweapon
      isRemove: true
    - controller: controller.render.test_mod_player.first_person
      condition: variable.is_first_person

  animate:
    - key: attack1
      name: animation.test_mod_doublegun.attack_1
    - key: attack2
      name: animation.test_mod_doublegun.attack_2
    - key: attack3
      name: animation.test_mod_doublegun.attack_3
    - key: attack4
      name: animation.test_mod_doublegun.attack_4

  animate_controller:
    - key: attack_controller
      name: controller.animation.test_mod_sword.attack
    - type: first_person
      key: test_mod_weapon_firstperson_controller
      name: controller.animation.test_mod_sword
    - type: third_person
      key: test_mod_weapon_controller
      name: controller.animation.test_mod_sword
```

完整原件位于配套包的同名路径，包含待机、移动、翻滚和原版动作屏蔽项。

### 2. WeaponAttackCDConfig：连击和客户端速度

文件：

```text
Molang/WeaponAttackCDConfig/NormalAttack/twoqiang.yml
```

每段都做两件事：

1. 把 `min`、`max`、`changeTime` 除以倍率 `S`。
2. 在攻击段开始前，把 `query.mod.twoqiang_attack_speed` 写成 `S`。

```yaml
test_mod:twoqiang:
  itemId: "test_mod:twoqiang"
  cdList:
    - min: "0.6 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      max: "1.5 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      changeTime: "0.78 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      molang:
        - key: "query.mod.twoqiang_attack_speed"
          value: "min(1 + max(%player_level%, 0) * 0.02, 2)"
          resetValue: 1

    - min: "0.6 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      max: "1.8 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      changeTime: "0.78 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      molang:
        - key: "query.mod.twoqiang_attack_speed"
          value: "min(1 + max(%player_level%, 0) * 0.02, 2)"
          resetValue: 1

    - min: "0.6 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      max: "0.72 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      changeTime: "0.72 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      molang:
        - key: "query.mod.twoqiang_attack_speed"
          value: "min(1 + max(%player_level%, 0) * 0.02, 2)"
          resetValue: 1

  specialEffectList:
    - min: "0.1 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      max: "0.6 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      molang:
        - key: "query.mod.attack_special_effect"
          value: 1
    - min: "0.1 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      max: "0.6 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      molang:
        - key: "query.mod.attack_special_effect"
          value: 2
    - min: "0.1 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      max: "0.6 / min(1 + max(%player_level%, 0) * 0.02, 2)"
      molang:
        - key: "query.mod.attack_special_effect"
          value: 3
```

`specialEffectList.value` 的 `1/2/3` 是特效编号，不是速度。速度仍由 `query.mod.twoqiang_attack_speed` 控制。

### 3. TrackingTimeConfig：刀光追踪

文件：

```text
Molang/TrackingTimeConfig/NormalAttack/twoqiang.yml
```

该文件分别配置第一人称和第三人称每段攻击的 Locator、刀光颜色、宽度、长度和追踪时间。

当前所有段使用 `texture: f1`，对应组件资源：

```text
resource_packs/better_appearance_res/textures/models/f1.png
```

复制 TrackingTime 配置时必须同时保留这张贴图，否则刀光系统仍会收到时间和 Locator，但无法使用当前配置指定的纹理。

当前时间为静态数字：

| 视角 | 段位 | trackingMinTime | trackingMaxTime |
|---|---:|---:|---:|
| 第一人称 | 1 | 0.2 | 0.45 |
| 第一人称 | 2 | 0.2 | 0.6 |
| 第一人称 | 3 | 0.2 | 0.9 |
| 第三人称 | 1 | 0.1 | 0.15 |
| 第三人称 | 2 | 0.05 | 0.09 |
| 第三人称 | 3 | 0.05 | 0.1 |

当前 `TrackingTimeConfig` 没有接入玩家 PAPI 快照解析。不要直接把这两个字段改成字符串表达式；客户端现有链路需要数字。攻击速度提高后，如果刀光时机明显错位，需要先扩展 TrackingTime 的动态快照能力。

### 4. WeaponAttackDamageConfig：服务端指令

文件：

```text
ServerEffect/WeaponAttackDamageConfig/NormalAttack/twoqiang.yml
```

`delay` 单位为 tick，动态表达式会在服务端刷新玩家快照时解析并四舍五入成整数。

当前配置：

```yaml
test_mod:twoqiang:
  itemId: "test_mod:twoqiang"
  extremeOpenRange: 1
  commandList:
    -
      - delay: "2 / min(1 + max(%player_level%, 0) * 0.02, 2)"
        command: "[console] apmm cast 玩家双枪普通攻击1 %player%"
    -
      - delay: "2 / min(1 + max(%player_level%, 0) * 0.02, 2)"
        command: "[console] apmm cast 玩家双枪普通攻击2 %player%"
    -
      - delay: "5 / min(1 + max(%player_level%, 0) * 0.02, 5)"
        command: "[console] apmm cast 玩家双枪强化普攻1 %player%"
```

这里有两项必须由技术人员确认：

- `extremeOpenRange: 1` 表示允许 1 秒误差，远高于文件注释建议的 `0` 到 `0.2`。这会明显放宽服务端攻击间隔校验。
- 第三段 `delay` 的倍率上限为 `5`，而玩家动作和特效动作上限为 `2`。50 级以后动作不再加速，但第三段指令仍会继续提前。

如果这两项不是有意设计，推荐改为：

```yaml
extremeOpenRange: 0.2

# 第三段
- delay: "5 / min(1 + max(%player_level%, 0) * 0.02, 2)"
```

配套包保留当前原件，不擅自替换这两个值。

### 5. 双枪技能配置

当前服务端还存在三份双枪技能配置：

```text
ActionEffect/GeoAction/SkillAttack/twoqiangskill1.yml
Molang/WeaponAttackCDConfig/SkillAttack/twoqiang_skill.yml
ServerEffect/WeaponAttackDamageConfig/SkillAttack/twoqiang_skill.yml
```

它们按以下五个 `skillId` 注册技能，不按物品 `itemId` 注册：

| 技能 | 玩家动作 | 特效 Molang |
|---|---|---|
| 炽烈疾射 | `animation.test_mod_doublegun.skill_1` | `query.mod.skill1_special_effect` |
| 星辉爆裂 | `animation.test_mod_doublegun.skill_2` | `query.mod.skill2_special_effect` |
| 焚心弹幕 | `animation.test_mod_doublegun.skill_3` | `query.mod.skill3_special_effect` |
| 烈火奔流 | `animation.test_mod_doublegun.skill_4` | `query.mod.skill4_special_effect` |
| 灼魂风暴 | `animation.test_mod_doublegun.skill_5` | `query.mod.skill5_special_effect` |

技能链路与 `test_mod:twoqiang` 的关系来自组件附加物：附加物同时预注册了五个玩家技能动作和五套技能模型特效。只有外部技能系统用上述 `skillId` 调用 BetterAppearance 技能接口时，这三份服务端配置才会参与执行。仅拿起 `test_mod:twoqiang` 不会自动释放这些技能。

这三份配置当前使用各自的静态技能时间和 `delay`，没有使用 `query.mod.twoqiang_attack_speed`。普通攻击速度教程中的倍率不会自动影响技能速度。

### 6. 旧双枪配置

当前服务端还保留了旧标识 `test_mod:doublegun_normal`：

```text
ActionEffect/GeoAction/NormalAttack/doublegun_normal.yml
Molang/WeaponAttackCDConfig/NormalAttack/doublegun_normal.yml
```

它与 `test_mod:twoqiang` 是两个独立 `itemId`，不能互相匹配。旧配置使用同一批 `animation.test_mod_doublegun.*` 玩家动作和共享 Controller，但模型特效几何、贴图及部分动作映射与当前配置不同。

配套包保留这两份历史配置及其组件物品定义，方便学习者比较旧写法。部署当前双枪时不需要同时启用旧标识，也不要把两个 identifier 当作别名。

## 五、组件资源链路

### 1. 物品和附加物

| 文件 | 作用 |
|---|---|
| `behavior_packs/better_appearance_beh/netease_items_beh/twoqiang.json` | 注册 `test_mod:twoqiang` 行为包物品。 |
| `resource_packs/better_appearance_res/attachables/testtwoqiang.json` | 为同 identifier 注册普攻和技能模型特效、状态机、模型、贴图及 Render Controller。 |

附加物只在第三人称执行默认特效控制器：

```json
"animate": [
  {"default_controller": "context.is_first_person == 0.0"}
]
```

当前 Render Controller 列表只启用了普通攻击特效 `1/2/3`。虽然文件里还映射了 `attack4/attack5`，当前三段普攻不会进入这些状态。

当前组件没有单独的 `netease_items_res` 文件注册 `test_mod:twoqiang` 图标；手持显示依赖附加物和 BetterAppearance 注入到玩家资源的武器模型。

配套包还保留三份旧双枪物品文件：

```text
behavior_packs/better_appearance_beh/netease_items_beh/testdouble.json
resource_packs/better_appearance_res/netease_items_res/test_mod/doublegun_normal.json
resource_packs/better_appearance_res/netease_items_res/test_mod_doublegun_normal.json
```

前两份注册的是 `test_mod:doublegun_normal`，第三份当前只是空 JSON 残留。它们不属于 `test_mod:twoqiang` 当前 identifier 链路。

### 2. 玩家武器模型和动作

| 文件 | 作用 |
|---|---|
| `models/entity/weapon/twoqiang.geo.json` | 定义 `geometry.test_mod_doublegun`。 |
| `textures/entity/test_mod/twoqiang.png` | 双枪玩家武器贴图。 |
| `animations/test_mod/test_mod_twoqiang.animation.json` | 双枪待机、移动、四段攻击和五个技能动作。 |
| `animations/test_mod/test_mod_player.null.json` | 用空动作屏蔽部分原版动作。 |

前三段攻击已经加入：

```json
"anim_time_update": "query.anim_time + query.delta_time * (query.mod.twoqiang_attack_speed > 0 ? query.mod.twoqiang_attack_speed : 1)"
```

未启用的 `animation.test_mod_doublegun.attack_4` 没有加入动态速度。

### 3. 普攻模型特效

| 文件 | 作用 |
|---|---|
| `animations/twoqiang/twoqiang_vfx_attack.animation.json` | 定义普通攻击模型特效动作。 |
| `models/entity/special/twoqiang/twoqiang_vfx_attack.geo.json` | 定义 `geometry.twoqiang_vfx_attack`。 |
| `textures/entity/twoqiang/twoqiang_vfx_attack.png` | 附加物实际引用的普攻特效贴图。 |

前三段特效动作也使用相同的 `query.mod.twoqiang_attack_speed`。这样玩家动作、特效关键帧和 `specialEffectList` 显示窗口才处于同一时间轴。

### 4. 技能模型特效资源

附加物预留了技能 1 到技能 5，因此配套包包含：

```text
animations/twoqiang/skill/
models/entity/special/twoqiang/twoqiang_vfx_skill_1.geo.json
models/entity/special/twoqiang/twoqiang_vfx_skill_2.geo.json
models/entity/special/twoqiang/twoqiang_vfx_skill_3.geo.json
models/entity/special/twoqiang/twoqiang_vfx_skill_4.geo.json
models/entity/special/twoqiang/twoqiang_vfx_skill_5.geo.json
textures/entity/twoqiang/twoqiang_vfx_skill_1.png
textures/entity/twoqiang/twoqiang_vfx_skill_2345.png
```

当前服务端同时提供了五个中文 `skillId` 的 `SkillAttack` 配置，分别负责技能动作替换、技能 CD/特效时间和服务端指令。它们是否生效取决于外部技能系统是否用一致的 `skillId` 调用插件，不由 `test_mod:twoqiang` 物品自动触发。

### 5. 共享控制器

| 文件 | 作用 |
|---|---|
| `animation_controllers/test_mod/test_mod_sword.animation_controllers.json` | 玩家武器总控制器和攻击控制器。 |
| `animation_controllers/special_effects/special_effects_controller.json` | 根据普攻/技能特效 Molang 选择附加物动作。 |
| `render_controllers/test_mod/test_mod_weapon.render_controllers.json` | 双枪主手/副手武器渲染。 |
| `render_controllers/test_mod/test_mod_player.render_controllers.json` | 玩家第一人称渲染。 |
| `render_controllers/test_mod/special_effects.render_controllers.json` | 普攻和技能模型特效渲染。 |

这些文件是共享文件。合并到其他版本组件时不能直接覆盖，需要比较并合并对应 Controller。

### 6. 音效

配套包包含：

```text
sounds/sound_definitions.json
sounds/twoqiang_sound/
```

`sound_definitions.json` 注册了四个双枪普攻音效和五个技能音效。当前双枪动画 JSON 没有 `sound_effects` 时间轴，因此仅包含音频文件和注册项不会自动播放声音；还需要其他系统或动画事件主动触发。

## 六、当前配置审计结果

### 1. 第四段只完成了部分资源

以下位置存在第四段：

- `ActionEffect` 中有 `attack4`。
- 玩家动画中有 `animation.test_mod_doublegun.attack_4`。
- 附加物映射中有普通特效 `attack4/attack5`。
- 普攻特效动画中有 `attack_4`。

但以下服务端配置只有三段：

- `cdList`。
- `specialEffectList`。
- `commandList`。
- 当前附加物 Render Controller 启用列表。

因此当前有效连击仍是三段。不要仅增加客户端 `attack4` 就认为第四段已经完成。

### 2. ActionEffect 中存在当前组件找不到的动作名

当前组件能够找到：

```text
animation.test_mod_doublegun.attack_1/2/3/4
animation.test_mod_player.null
controller.animation.test_mod_sword
controller.animation.test_mod_sword.attack
```

但当前 `ActionEffect` 还引用了若干未在本组件中找到直接定义的动作，例如：

```text
animation.test_mod_twoqiang.idle
animation.test_mod_twoqiang.run
animation.test_mod_twoqiang.walk
animation.test_mod_twoqiangb.walk
animation.test_mod_spear.*_ymd
animation.test_mod_sword.idle_fly
animation.test_mod_sword.roll_first
animation.test_mod_player.meditation
animation.test_mod_player.climb_idle
```

同一个双枪动画文件中实际存在的待机和移动命名空间是：

```text
animation.test_mod_doublegun.idle
animation.test_mod_doublegun.run
animation.test_mod_doublegun.walk
animation.test_mod_doublegun.jump
animation.test_mod_doublegun.jump_1
```

如果服务器还有额外资源包提供上述共享动作，则需要一并部署；如果没有，就应先确认这些命名空间是否为历史残留。配套包不会凭猜测改名。

### 3. 重复贴图

组件中同时存在：

```text
textures/entity/twoqiang_vfx_attack.png
textures/entity/twoqiang/twoqiang_vfx_attack.png
```

技能贴图也有相同的根目录/子目录重复。当前附加物实际引用的是 `textures/entity/twoqiang/` 子目录版本。配套包仍保留全部双枪命名文件，便于对照历史资源；新项目应只保留实际引用版本。

### 4. 名称相关但不属于当前链路的测试代码

组件脚本 `behavior_packs/better_appearance_beh/better_appearance_scripts/server/modServer.py` 中有一段测试代码会生成 `netease:doublegun` 实体。这个实体 identifier 既不是 `test_mod:twoqiang`，也不是 `test_mod:doublegun_normal`，不参与本教程的物品、动作或攻击配置链路，因此没有放入配套包。

## 七、动态刷新

等级、属性或 Buff 变化后，外部插件应调用：

```java
/**
 * 玩家攻击速度属性变化后刷新攻击配置快照。
 *
 * @param player 属性发生变化的在线玩家
 */
public void refreshTwoqiangAttackSpeed(Player player) {
    BetterAppearance.getInstance()
            .getApi()
            .getSkillService()
            .updateSkillCD(player);
}
```

该 API 会重新解析：

- `cdList.min/max/changeTime`。
- 分段 `molang.value/resetValue`。
- `specialEffectList.min/max/molang.value`。
- 服务端 `commandList.delay`。
- 普通技能和伪装技能的同类攻击配置。

不要每 tick 刷新，只在属性值实际变化时调用。连击中途收到新快照时，当前轮继续使用旧值，下一轮使用新值。

## 八、部署步骤

1. 确认服务端已经安装支持动态玩家表达式和动态指令 `delay` 的当前 BetterAppearance 插件版本。
2. 只部署普通攻击时，合并 `test_mod:twoqiang` 对应的四份 YAML；需要五个双枪技能时，再合并三份 `SkillAttack` YAML。
3. 不要直接覆盖共享 Controller，先与现有组件版本比较并合并。
4. 把双枪专用模型、动画、贴图、音效、物品和附加物复制到行为包/资源包对应路径。
5. 确认服务端物品带 `netease_identifier: test_mod:twoqiang`。
6. 执行 `papi parse 玩家名 %player_level%`，确认输出纯数字。
7. 执行 `/peba reload` 或重启服务端。
8. 让客户端重新下载并加载组件资源，服务端重载不能替代资源包更新。
9. 测试 0、25、50 级玩家的三段攻击。
10. 两名玩家互相观察，验证攻击者和观察者看到的玩家动作、模型特效与伤害时机一致。

## 九、验收清单

- 主手切换到双枪时，玩家武器模型正常出现。
- 切换离开或丢弃双枪时，玩家模型和攻击配置正常恢复。
- 三段玩家动作均读取 `query.mod.twoqiang_attack_speed`。
- 三段普攻模型特效动作均读取相同速度 Molang。
- `specialEffectList.value` 依次为 `1/2/3`。
- `min/max/changeTime` 与模型特效显示窗口使用同一个倍率上限。
- 服务端三段 `delay` 是否有意使用相同倍率上限已经确认。
- `extremeOpenRange` 是否确实需要 `1` 已经确认。
- 动态属性变化后只刷新一次快照，不存在每 tick 刷新。
- 当前未启用的第四段不会被客户端误触发。
- 第一人称引用的共享动作资源确实存在于最终加载的全部资源包中。
- 刀光追踪时间仍为静态这一限制已经被玩法接受。

## 十、配套包结构

```text
test_mod_twoqiang完整教程包/
├─ README.md
├─ 服务端配置/
│  └─ BetterAppearance/
│     ├─ ActionEffect/GeoAction/NormalAttack/twoqiang.yml
│     ├─ ActionEffect/GeoAction/NormalAttack/doublegun_normal.yml
│     ├─ ActionEffect/GeoAction/SkillAttack/twoqiangskill1.yml
│     ├─ Molang/WeaponAttackCDConfig/NormalAttack/twoqiang.yml
│     ├─ Molang/WeaponAttackCDConfig/NormalAttack/doublegun_normal.yml
│     ├─ Molang/WeaponAttackCDConfig/SkillAttack/twoqiang_skill.yml
│     ├─ Molang/TrackingTimeConfig/NormalAttack/twoqiang.yml
│     ├─ ServerEffect/WeaponAttackDamageConfig/NormalAttack/twoqiang.yml
│     └─ ServerEffect/WeaponAttackDamageConfig/SkillAttack/twoqiang_skill.yml
├─ 组件资源/
│  ├─ behavior_packs/better_appearance_beh/...
│  └─ resource_packs/better_appearance_res/...
└─ 文件清单.sha256
```

这个 ZIP 是用于合并和学习的资源片段，不是独立完整组件。它依赖 BetterAppearance 基础组件中的玩家资源注册、脚本系统和通用 Molang 系统。
